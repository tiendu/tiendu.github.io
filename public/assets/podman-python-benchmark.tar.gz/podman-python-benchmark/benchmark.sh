#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
export LC_ALL=C

base_image="docker.io/library/python:3.13.5-slim-bookworm"
cold_runs="${COLD_RUNS:-3}"
warm_runs="${WARM_RUNS:-3}"
keep_archives="${KEEP_ARCHIVES:-0}"
prune_between_cold_runs="${PRUNE_BETWEEN_COLD_RUNS:-0}"
read -r -a build_flags <<< "${PODMAN_BUILD_FLAGS:-}"

[[ -d vendor ]] || {
  echo "vendor/ is missing; run ./prepare-wheels.sh first" >&2
  exit 1
}

mkdir -p results
printf 'phase,variant,run,seconds\n' > results/timings.csv
printf 'variant,size_bytes,compressed_bytes,layers\n' > results/images.csv

if [[ "${SKIP_PULL:-0}" != "1" ]]; then
  podman pull "$base_image" >/dev/null
fi
podman image inspect "$base_image" --format '{{.Digest}}' > results/base-digest.txt
podman version --format '{{.Client.Version}}' > results/podman-version.txt

timestamp_ns() {
  python3 - <<'PY'
import time
print(time.perf_counter_ns())
PY
}

elapsed_seconds() {
  python3 - "$1" "$2" <<'PY'
import sys
start, end = map(int, sys.argv[1:])
print(f"{(end - start) / 1_000_000_000:.3f}")
PY
}

original_app="$(mktemp)"
cp app.py "$original_app"
cleanup() {
  cp "$original_app" app.py
  rm -f "$original_app"
}
trap cleanup EXIT

for variant in simple optimized multistage; do
  file="Containerfile.${variant}"
  image="localhost/podman-python-${variant}:latest"

  for run in $(seq 1 "$cold_runs"); do
    podman rmi --force "$image" >/dev/null 2>&1 || true
    start="$(timestamp_ns)"
    podman build "${build_flags[@]}" \
      --no-cache \
      --file "$file" \
      --tag "$image" . >/dev/null
    end="$(timestamp_ns)"
    seconds="$(elapsed_seconds "$start" "$end")"
    printf 'cold,%s,%s,%s\n' "$variant" "$run" "$seconds" | tee -a results/timings.csv

    if [[ "$prune_between_cold_runs" == "1" ]]; then
      podman image prune --force >/dev/null
    fi
  done

  cp "$original_app" app.py
  podman build "${build_flags[@]}" --file "$file" --tag "$image" . >/dev/null

  for run in $(seq 1 "$warm_runs"); do
    printf '\n# benchmark source change: %s %s\n' "$variant" "$run" >> app.py
    start="$(timestamp_ns)"
    podman build "${build_flags[@]}" --file "$file" --tag "$image" . >/dev/null
    end="$(timestamp_ns)"
    seconds="$(elapsed_seconds "$start" "$end")"
    printf 'warm,%s,%s,%s\n' "$variant" "$run" "$seconds" | tee -a results/timings.csv
  done
  cp "$original_app" app.py

  size_bytes="$(podman image inspect --format '{{.Size}}' "$image")"
  layers="$(podman image inspect --format '{{len .RootFS.Layers}}' "$image")"
  archive="results/${variant}.tar.gz"
  podman save "$image" | gzip -9 > "$archive"
  compressed_bytes="$(wc -c < "$archive" | tr -d ' ')"
  printf '%s,%s,%s,%s\n' \
    "$variant" "$size_bytes" "$compressed_bytes" "$layers" \
    | tee -a results/images.csv

  podman history --human --no-trunc "$image" > "results/history-${variant}.txt"
  if [[ "$keep_archives" != "1" ]]; then
    rm -f "$archive"
  fi
done

python3 summarize.py
printf '\nRun ./smoke-test.sh to validate the final images.\n'
