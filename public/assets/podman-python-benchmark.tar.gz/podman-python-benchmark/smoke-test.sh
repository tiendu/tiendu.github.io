#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
read -r -a run_flags <<< "${PODMAN_RUN_FLAGS:-}"
host_network="${PODMAN_RUN_HOST_NETWORK:-0}"

for variant in simple optimized multistage; do
  image="localhost/podman-python-${variant}:latest"
  container="podman-python-${variant}-smoke"
  podman rm --force "$container" >/dev/null 2>&1 || true

  if [[ "$host_network" == "1" ]]; then
    podman run --detach --name "$container" \
      "${run_flags[@]}" --network host "$image" >/dev/null
    base_url="http://127.0.0.1:8000"
  else
    podman run --detach --name "$container" \
      "${run_flags[@]}" --publish 127.0.0.1::8000 "$image" >/dev/null
    port="$(podman port "$container" 8000/tcp | awk -F: '{print $NF}')"
    base_url="http://127.0.0.1:${port}"
  fi

  ready=0
  for _ in $(seq 1 40); do
    if curl --fail --silent "$base_url/health" >/dev/null; then
      ready=1
      break
    fi
    sleep 0.25
  done
  [[ "$ready" == "1" ]] || {
    podman logs "$container" >&2 || true
    exit 1
  }

  curl --fail --silent "$base_url/summary?values=10,20,30" | tee /dev/stderr | grep --quiet '"mean":20.0'
  curl --fail --silent "$base_url/versions" | tee /dev/stderr | grep --quiet '"psycopg":"3.3.4"'
  podman rm --force "$container" >/dev/null
  printf '%s: OK\n' "$variant"
done
