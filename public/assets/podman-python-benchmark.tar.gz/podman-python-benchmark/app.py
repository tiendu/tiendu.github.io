from __future__ import annotations

from importlib.metadata import version

import numpy as np
import pandas as pd
import psycopg
import sqlalchemy
from fastapi import FastAPI, Query

app = FastAPI(title="Podman build benchmark")


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/summary")
def summary(
    values: str = Query(default="10,20,30,40"),
) -> dict[str, float | int]:
    numbers = np.fromstring(values, sep=",")
    if numbers.size == 0:
        return {"count": 0, "mean": 0.0, "median": 0.0}

    series = pd.Series(numbers)
    return {
        "count": int(series.count()),
        "mean": float(series.mean()),
        "median": float(series.median()),
    }


@app.get("/versions")
def versions() -> dict[str, str]:
    # Importing SQLAlchemy and psycopg verifies that their runtime
    # dependencies are available. No database connection is needed.
    return {
        "fastapi": version("fastapi"),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "sqlalchemy": sqlalchemy.__version__,
        "psycopg": psycopg.__version__,
    }
