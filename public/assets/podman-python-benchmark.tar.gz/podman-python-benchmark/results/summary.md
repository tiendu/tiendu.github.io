# Benchmark result summary

## Build times

| Phase | Variant | Mean | Minimum | Maximum |
|---|---|---:|---:|---:|
| cold | multistage | 127.160 s | 118.590 s | 139.152 s |
| cold | optimized | 91.737 s | 87.903 s | 95.100 s |
| cold | simple | 58.328 s | 56.026 s | 62.119 s |
| warm | multistage | 72.641 s | 66.864 s | 80.812 s |
| warm | optimized | 58.710 s | 55.416 s | 60.661 s |
| warm | simple | 66.927 s | 62.763 s | 71.795 s |

## Final images

| Variant | Local size | Gzip archive | Layers |
|---|---:|---:|---:|
| simple | 411.9 MiB | 165.4 MiB | 6 |
| optimized | 363.6 MiB | 147.6 MiB | 8 |
| multistage | 312.5 MiB | 97.2 MiB | 6 |
