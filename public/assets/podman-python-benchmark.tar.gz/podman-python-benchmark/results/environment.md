# Benchmark environment

- Podman: 5.8.4
- Architecture: x86_64
- Host: Debian GNU/Linux 13
- Memory available to the runner: approximately 4 GiB
- Base image: `python:3.13.5-slim-bookworm`
- Base digest: `sha256:a7cb177dc60dfa77b223192cd0d9e6ce1aac7cf9a569023d68e7c91b6371a718`
- Package source: local pinned wheelhouse
- Runs: three cold builds and three source-only rebuilds per variant
- Storage driver: VFS
- Build isolation: chroot

The benchmark ran inside a nested sandbox. VFS copies considerably more filesystem data than OverlayFS or `fuse-overlayfs`, so the absolute build times are specific to this runner. The cache-invalidation pattern and final image contents are the more portable results.
