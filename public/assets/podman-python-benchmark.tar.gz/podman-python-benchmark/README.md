# Podman Python image benchmark

This project reproduces the benchmark used in the post **Podman Container Builds: Simple vs Multi-Stage, Benchmarked**.

It builds the same FastAPI application three ways:

1. `Containerfile.simple` — naïve one-stage build with development dependencies
2. `Containerfile.optimized` — cache-aware one-stage production build
3. `Containerfile.multistage` — builder stage plus a production runtime stage

The application uses FastAPI, Uvicorn, NumPy, Pandas, SQLAlchemy, and psycopg. All dependencies are pinned.

## Requirements

- Podman
- Python 3
- `curl`
- Network access for the initial base-image pull and wheel download

The timed builds use a local `vendor/` wheelhouse, so PyPI network speed is not included in the measurements.

## Run the benchmark

Prepare Linux wheels using the same Python base image:

```bash
./prepare-wheels.sh
```

Optionally test the application on the host:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install \
  --no-index \
  --find-links=vendor \
  -r requirements-dev.txt
.venv/bin/python -m pytest
.venv/bin/python -m ruff check .
```

Run three cold builds and three source-only rebuilds per image:

```bash
./benchmark.sh
```

Validate all final images:

```bash
./smoke-test.sh
```

Useful overrides:

```bash
COLD_RUNS=5 WARM_RUNS=5 ./benchmark.sh
KEEP_ARCHIVES=1 ./benchmark.sh
PODMAN_BUILD_FLAGS="--jobs=2" ./benchmark.sh
```

`PRUNE_BETWEEN_COLD_RUNS=1` is available for constrained environments, but it changes local cache state and is disabled by default.

## Outputs

The benchmark writes:

- `results/timings.csv` — raw cold and source-only build timings
- `results/images.csv` — local image size, compressed archive size, and layer count
- `results/history-*.txt` — full `podman history` output
- `results/base-digest.txt` — resolved base-image digest
- `results/summary.md` — compact result tables

The included `results/` directory contains the actual run used in the post. The runner used Podman 5.8.4 with the VFS storage driver inside a nested Debian 13 sandbox. Treat its absolute build times as environment-specific.

## Results from the published run

| Variant | Cold build mean | Source-only rebuild mean | Local image | Gzip archive |
|---|---:|---:|---:|---:|
| Naïve one-stage | 58.3 s | 66.9 s | 411.9 MiB | 165.4 MiB |
| Cache-aware one-stage | 91.7 s | 58.7 s | 363.6 MiB | 147.6 MiB |
| Multi-stage | 127.2 s | 72.6 s | 312.5 MiB | 97.2 MiB |

The multi-stage image was 51.1 MiB smaller locally and 50.5 MiB smaller as a gzip archive than the cache-aware one-stage image. The timing results are heavily affected by VFS; the final image composition is the more portable finding.
