from __future__ import annotations

import csv
import statistics
from collections import defaultdict
from pathlib import Path

results = Path("results")
rows = list(csv.DictReader((results / "timings.csv").open(encoding="utf-8")))
groups: dict[tuple[str, str], list[float]] = defaultdict(list)
for row in rows:
    groups[(row["phase"], row["variant"])].append(float(row["seconds"]))

lines = [
    "# Benchmark result summary",
    "",
    "## Build times",
    "",
    "| Phase | Variant | Mean | Minimum | Maximum |",
    "|---|---|---:|---:|---:|",
]
for (phase, variant), values in sorted(groups.items()):
    lines.append(
        f"| {phase} | {variant} | {statistics.mean(values):.3f} s "
        f"| {min(values):.3f} s | {max(values):.3f} s |"
    )

image_rows = list(csv.DictReader((results / "images.csv").open(encoding="utf-8")))
lines.extend(
    [
        "",
        "## Final images",
        "",
        "| Variant | Local size | Gzip archive | Layers |",
        "|---|---:|---:|---:|",
    ]
)
for row in image_rows:
    local_mib = int(row["size_bytes"]) / 1024 / 1024
    archive_mib = int(row["compressed_bytes"]) / 1024 / 1024
    lines.append(
        f"| {row['variant']} | {local_mib:.1f} MiB | "
        f"{archive_mib:.1f} MiB | {row['layers']} |"
    )

summary = "\n".join(lines) + "\n"
(results / "summary.md").write_text(summary, encoding="utf-8")
print(summary, end="")
