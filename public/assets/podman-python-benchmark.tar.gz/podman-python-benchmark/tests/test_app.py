from fastapi.testclient import TestClient

from app import app

client = TestClient(app)


def test_health() -> None:
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}


def test_summary() -> None:
    response = client.get("/summary", params={"values": "10,20,30"})
    assert response.status_code == 200
    assert response.json() == {"count": 3, "mean": 20.0, "median": 20.0}
