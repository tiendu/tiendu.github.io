#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
base_image="docker.io/library/python:3.13.5-slim-bookworm"

rm -rf vendor
mkdir -p vendor

podman pull "$base_image"
podman run --rm \
  --volume "$PWD:/work:Z" \
  --workdir /work \
  "$base_image" \
  python -m pip download \
    --only-binary=:all: \
    --dest vendor \
    --requirement requirements-dev.txt

printf 'Downloaded wheelhouse: '
du -sh vendor | cut -f1
